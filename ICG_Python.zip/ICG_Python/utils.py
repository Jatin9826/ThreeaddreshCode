def display_tac(tac):
    print("\nThree Address Code:")
    for line in tac:
        print(line)
